<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.urbanui.com/public/newtemplate/pages/samples/lock-screen.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Oct 2019 07:01:51 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php if(!empty($site_name)){ echo $site_name; } ?> | <?php echo $title; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/newtemplate/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/newtemplate/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/newtemplate/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/newtemplate/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>public/newtemplate/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>public/newtemplate/images/icon.png" />
  
  
    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url(); ?>public/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="<?php echo base_url(); ?>public/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    
    
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper">
      <div class="row">
        <div class="content-wrapper full-page-wrapper d-flex align-items-center auth lock-full-bg">
          <div class="row w-100">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-transparent text-left p-5 text-center">
                <img src="<?php echo base_url(); ?>public/newtemplate/images/auth/hssepass-logo.png" alt="profile" class="lock-profile-img">
                <?php echo $content; ?>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- row ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  
</body>

  <script src="<?php echo base_url(); ?>public/newtemplate/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo base_url(); ?>public/newtemplate/js/off-canvas.js"></script>
  <script src="<?php echo base_url(); ?>public/newtemplate/js/hoverable-collapse.js"></script>
  <script src="<?php echo base_url(); ?>public/newtemplate/js/misc.js"></script>
  <script src="<?php echo base_url(); ?>public/newtemplate/js/settings.js"></script>
  <script src="<?php echo base_url(); ?>public/newtemplate/js/todolist.js"></script>
<!-- Mirrored from www.urbanui.com/public/newtemplate/pages/samples/lock-screen.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Oct 2019 07:01:51 GMT -->
</html>
